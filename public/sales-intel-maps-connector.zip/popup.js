(function () {
  "use strict";

  const el = {
    envBadge: document.getElementById("envBadge"),
    connectionStatus: document.getElementById("connectionStatus"),
    statusTitle: document.getElementById("statusTitle"),
    statusUser: document.getElementById("statusUser"),
    mapsDot: document.getElementById("mapsDot"),
    mapsStatusTitle: document.getElementById("mapsStatusTitle"),
    queryInfo: document.getElementById("queryInfo"),
    detectedInfo: document.getElementById("detectedInfo"),
    cardStats: document.getElementById("cardStats"),
    statQualifiedLive: document.getElementById("statQualifiedLive"),
    statSkippedLive: document.getElementById("statSkippedLive"),
    statDuplicatesLive: document.getElementById("statDuplicatesLive"),
    importLimit: document.getElementById("importLimit"),
    quickCsvBtn: document.getElementById("quickCsvBtn"),
    extractBtn: document.getElementById("extractBtn"),
    stopBtn: document.getElementById("stopBtn"),
    importHint: document.getElementById("importHint"),
    progressContainer: document.getElementById("progressContainer"),
    progressBar: document.getElementById("progressBar"),
    progressText: document.getElementById("progressText"),
    resultSummary: document.getElementById("resultSummary"),
    summaryTitle: document.getElementById("summaryTitle"),
    statDiscovered: document.getElementById("statDiscovered"),
    statQualified: document.getElementById("statQualified"),
    statSkipped: document.getElementById("statSkipped"),
    statDuplicates: document.getElementById("statDuplicates"),
    statReady: document.getElementById("statReady"),
    downloadCsvBtn: document.getElementById("downloadCsvBtn"),
    importBackendBtn: document.getElementById("importBackendBtn"),
    openAppBtn: document.getElementById("openAppBtn"),
    viewLeadsBtn: document.getElementById("viewLeadsBtn"),
    settingsBtn: document.getElementById("settingsBtn"),
    reconnectBtn: document.getElementById("reconnectBtn"),
  };

  let connectedTabId = null;
  let currentExtractedLeads = [];
  let currentSearchQuery = null;
  let siConnected = false;

  // ─── Environment ─────────────────────────────────────────────────────────────
  function getEnv() {
    if (window.SalesIntelEnv) {
      const detected = window.SalesIntelEnv.resolveEnvironment(null, null);
      return detected;
    }
    return { env: "LOCAL", origin: "http://localhost:8080" };
  }

  function updateEnvBadge() {
    const env = getEnv();
    const isLocal = env.env === "LOCAL";
    el.envBadge.textContent = isLocal ? "LOCAL" : "PROD";
    el.envBadge.className = isLocal ? "badge badge-local" : "badge badge-prod";
  }

  function getBaseUrl() {
    return getEnv().origin;
  }

  // ─── Google Maps URL check ────────────────────────────────────────────────────
  function isGoogleMapsUrl(url) {
    if (!url) return false;
    try {
      const p = new URL(url);
      const host = p.hostname.toLowerCase();
      const isGoogle = host === "google.com" || host === "www.google.com" ||
        host === "maps.google.com" || /(^|\.)google\.[a-z.]+$/.test(host);
      const isMaps = p.pathname.startsWith("/maps") || host.startsWith("maps.google.");
      return isGoogle && isMaps;
    } catch { return false; }
  }

  // ─── CSV Generation ───────────────────────────────────────────────────────────
  function escapeCsvCell(val) {
    if (val == null) return "";
    const str = String(val);
    if (!str.length) return "";
    if (str.includes(",") || str.includes('"') || str.includes("\n") || str.includes("\r")) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  }

  const CSV_HEADERS = [
    "Company Name", "Industry", "Business Type",
    "Address", "City", "State / Region", "Country", "Postal Code",
    "Phone", "Website", "Email",
    "Rating", "Reviews", "Price Range", "Opening Status",
    "Booking URL", "Ordering URL", "Menu URL",
    "Google Maps URL", "Place ID", "Latitude", "Longitude",
    "Source", "Imported / Discovered Date",
  ];

  function generateCSV(leads) {
    const now = new Date().toISOString();
    const rows = [CSV_HEADERS.join(",")];
    for (const lead of leads) {
      if (!lead || !lead.company_name) continue;
      rows.push([
        escapeCsvCell(lead.company_name),
        escapeCsvCell(lead.category),
        escapeCsvCell(lead.business_type || lead.category),
        escapeCsvCell(lead.address),
        escapeCsvCell(lead.city),
        escapeCsvCell(lead.region),
        escapeCsvCell(lead.country),
        escapeCsvCell(lead.postal_code),
        escapeCsvCell(lead.phone),
        escapeCsvCell(lead.website),
        escapeCsvCell(lead.email),
        escapeCsvCell(lead.rating),
        escapeCsvCell(lead.review_count),
        escapeCsvCell(lead.price_range),
        escapeCsvCell(lead.opening_status),
        escapeCsvCell(lead.booking_url),
        escapeCsvCell(lead.ordering_url),
        escapeCsvCell(lead.menu_url),
        escapeCsvCell(lead.source_url),
        escapeCsvCell(lead.place_id),
        escapeCsvCell(lead.latitude),
        escapeCsvCell(lead.longitude),
        escapeCsvCell("google-maps"),
        escapeCsvCell(now),
      ].join(","));
    }
    return "\uFEFF" + rows.join("\r\n");
  }

  function triggerCsvDownload(csvText) {
    const now = new Date();
    const YYYY = now.getFullYear();
    const MM = String(now.getMonth() + 1).padStart(2, "0");
    const DD = String(now.getDate()).padStart(2, "0");
    let slug = "";
    if (currentSearchQuery) {
      slug = currentSearchQuery.toLowerCase().replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "").slice(0, 40);
    }
    const filename = slug
      ? `sales-intel-${slug}-${YYYY}-${MM}-${DD}.csv`
      : `sales-intel-google-maps-${YYYY}-${MM}-${DD}.csv`;
    const blob = new Blob([csvText], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
  }

  // ─── State 1: Sales Intel Connection ─────────────────────────────────────────
  function checkSalesIntelConnection() {
    chrome.runtime.sendMessage({ type: "SI_GET_STATUS" }, (res) => {
      if (chrome.runtime.lastError || !res || !res.connected) {
        siConnected = false;
        el.connectionStatus.className = "status-banner disconnected";
        el.statusTitle.textContent = "Not connected to Sales Intel";
        el.statusUser.textContent = "Open Settings to connect.";
        el.extractBtn.disabled = true;
        el.importBackendBtn && (el.importBackendBtn.disabled = true);
        el.importHint && el.importHint.classList.remove("hidden");
        return;
      }
      siConnected = true;
      el.connectionStatus.className = "status-banner connected";
      el.statusTitle.textContent = "Connected to Sales Intel";
      const user = res.user;
      el.statusUser.textContent = user
        ? (typeof user === "object" && user.email ? user.email : String(user))
        : "Active Session";
      el.importHint && el.importHint.classList.add("hidden");
    });
  }

  // ─── State 2: Google Maps Tab ─────────────────────────────────────────────────
  function setMapsNotOpen() {
    el.mapsDot.className = "maps-dot gray";
    el.mapsStatusTitle.textContent = "Open Google Maps to discover businesses.";
    el.queryInfo.classList.add("hidden");
    el.detectedInfo.textContent = "";
    el.cardStats && el.cardStats.classList.add("hidden");
    el.quickCsvBtn.disabled = true;
    el.extractBtn.disabled = true;
  }

  function setMapsNoResults() {
    el.mapsDot.className = "maps-dot green";
    el.mapsStatusTitle.textContent = "Google Maps detected";
    el.queryInfo.classList.add("hidden");
    el.detectedInfo.textContent = "No search results detected yet. Detected Cards: 0";
    el.cardStats && el.cardStats.classList.add("hidden");
    el.quickCsvBtn.disabled = true;
    el.extractBtn.disabled = true;
  }

  function applyMapsState(response) {
    el.mapsDot.className = "maps-dot green";
    el.mapsStatusTitle.textContent = "Google Maps detected";
    currentSearchQuery = response.query || null;
    if (response.query) {
      el.queryInfo.classList.remove("hidden");
      el.queryInfo.textContent = `Search: "${response.query}"`;
    } else {
      el.queryInfo.classList.add("hidden");
    }
    const detected = response.detected || 0;
    if (detected > 0) {
      el.detectedInfo.textContent = `Detected Cards: ${detected}`;
      el.quickCsvBtn.disabled = false;
      // Import button only enabled if also connected to SI
      el.extractBtn.disabled = !siConnected;
    } else {
      el.detectedInfo.textContent = "No search results detected yet. Detected Cards: 0";
      el.quickCsvBtn.disabled = true;
      el.extractBtn.disabled = true;
    }
    if (response.running) {
      el.extractBtn.classList.add("hidden");
      el.quickCsvBtn.classList.add("hidden");
      el.stopBtn.classList.remove("hidden");
      el.progressContainer.classList.remove("hidden");
    }
  }

  async function injectContentScripts(tabId) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: [
          "shared/constants.js", "shared/environment.js", "shared/schema.js",
          "content/maps/dom-utils.js", "content/maps/selectors.js",
          "content/maps/validators.js", "content/maps/address-parser.js",
          "content/maps/result-card-extractor.js",
          "content/maps/maps-adapter.js", "discovery.js",
        ],
      });
      return true;
    } catch { return false; }
  }

  async function checkGoogleMapsTab() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) { setMapsNotOpen(); return; }
      connectedTabId = tab.id;
      if (!isGoogleMapsUrl(tab.url)) { setMapsNotOpen(); return; }

      chrome.tabs.sendMessage(tab.id, { type: "SI_PAGE_STATE" }, async (response) => {
        if (chrome.runtime.lastError || !response || !response.ok) {
          const injected = await injectContentScripts(tab.id);
          if (injected) {
            chrome.tabs.sendMessage(tab.id, { type: "SI_PAGE_STATE" }, (r2) => {
              if (r2 && r2.ok) applyMapsState(r2);
              else setMapsNoResults();
            });
          } else { setMapsNoResults(); }
          return;
        }
        applyMapsState(response);
      });
    } catch { setMapsNotOpen(); }
  }

  // ─── Summary helpers ─────────────────────────────────────────────────────────
  function updateSummaryStats(stats, readyCount) {
    if (!stats) return;
    el.statDiscovered.textContent = stats.totalCandidates || 0;
    el.statQualified.textContent = stats.qualifiedBusinessCards || 0;
    el.statSkipped.textContent = (stats.skippedNonBusiness || 0) + (stats.skippedIncomplete || 0);
    el.statDuplicates.textContent = stats.duplicateCount || 0;
    el.statReady.textContent = readyCount != null ? readyCount : (stats.importedCount || 0);
  }

  // ─── Progress listener ────────────────────────────────────────────────────────
  function listenForProgress() {
    chrome.runtime.onMessage.addListener((message) => {
      if (!message || message.type !== "SI_DISCOVERY_PROGRESS") return;
      el.progressContainer.classList.remove("hidden");
      const found = message.found || 0;
      const target = Number(el.importLimit.value) || 10;
      const pct = Math.min(100, Math.round((found / target) * 100));
      el.progressBar.style.width = `${pct}%`;
      el.progressText.textContent = `Extracting & validating ${found} / ${target} leads...`;
      if (message.stats) {
        const s = message.stats;
        if (el.statQualifiedLive) el.statQualifiedLive.textContent = s.qualifiedBusinessCards || 0;
        if (el.statSkippedLive) el.statSkippedLive.textContent = (s.skippedNonBusiness || 0) + (s.skippedIncomplete || 0);
        if (el.statDuplicatesLive) el.statDuplicatesLive.textContent = s.duplicateCount || 0;
        if (el.cardStats) el.cardStats.classList.remove("hidden");
        updateSummaryStats(s, found);
      }
      if (message.status === "completed" || message.status === "cancelled") {
        el.extractBtn.classList.remove("hidden");
        el.quickCsvBtn.classList.remove("hidden");
        el.stopBtn.classList.add("hidden");
        el.progressContainer.classList.add("hidden");
        el.resultSummary.classList.remove("hidden");
        el.summaryTitle.textContent = message.status === "completed"
          ? "Discovery Complete" : "Extraction Stopped";
      }
    });
  }

  // ─── Extraction ───────────────────────────────────────────────────────────────
  function startExtraction(onComplete) {
    const limit = Number(el.importLimit.value) || 10;
    el.resultSummary.classList.add("hidden");
    el.extractBtn.classList.add("hidden");
    el.quickCsvBtn.classList.add("hidden");
    el.stopBtn.classList.remove("hidden");
    el.progressContainer.classList.remove("hidden");
    el.progressBar.style.width = "5%";
    el.progressText.textContent = "Initiating bulk extraction...";
    currentExtractedLeads = [];
    if (!connectedTabId) return;

    chrome.tabs.sendMessage(connectedTabId, { type: "SI_START_DISCOVERY", limit }, (res) => {
      el.extractBtn.classList.remove("hidden");
      el.quickCsvBtn.classList.remove("hidden");
      el.stopBtn.classList.add("hidden");
      el.progressContainer.classList.add("hidden");
      if (chrome.runtime.lastError || !res || !res.ok) {
        alert(res?.error || "Extraction failed.");
        return;
      }
      currentExtractedLeads = res.records || [];
      el.resultSummary.classList.remove("hidden");
      el.summaryTitle.textContent = "Discovery Complete";
      updateSummaryStats(res.stats, currentExtractedLeads.length);
      if (typeof onComplete === "function") onComplete(currentExtractedLeads);
    });
  }

  // ─── Actions ──────────────────────────────────────────────────────────────────
  function setupActions() {
    // Download CSV — works without SI connection
    el.quickCsvBtn.addEventListener("click", () => {
      if (currentExtractedLeads.length > 0) {
        triggerCsvDownload(generateCSV(currentExtractedLeads));
      } else {
        startExtraction((leads) => {
          if (leads && leads.length > 0) triggerCsvDownload(generateCSV(leads));
        });
      }
    });

    // Import to Sales Intel — requires connection
    el.extractBtn.addEventListener("click", () => {
      if (!siConnected) { alert("Connect Sales Intel first to import leads."); return; }
      startExtraction();
    });

    // Stop
    el.stopBtn.addEventListener("click", () => {
      if (connectedTabId) chrome.tabs.sendMessage(connectedTabId, { type: "SI_STOP_DISCOVERY" });
    });

    // Summary: Download CSV
    el.downloadCsvBtn.addEventListener("click", () => {
      if (!currentExtractedLeads || !currentExtractedLeads.length) {
        alert("No extracted leads ready to download."); return;
      }
      triggerCsvDownload(generateCSV(currentExtractedLeads));
    });

    // Summary: Import to Sales Intel
    el.importBackendBtn.addEventListener("click", () => {
      if (!siConnected) { alert("Connect Sales Intel first."); return; }
      if (!currentExtractedLeads || !currentExtractedLeads.length) {
        alert("No extracted leads ready to import."); return;
      }
      el.importBackendBtn.disabled = true;
      el.importBackendBtn.textContent = "Importing...";
      chrome.runtime.sendMessage({ type: "SI_BATCH_IMPORT", leads: currentExtractedLeads }, (res) => {
        el.importBackendBtn.disabled = false;
        el.importBackendBtn.textContent = "Import to Sales Intel";
        if (chrome.runtime.lastError || !res || !res.ok) {
          alert(res?.error || "Import failed."); return;
        }
        alert(`Successfully imported ${res.imported || currentExtractedLeads.length} lead(s)!`);
      });
    });

    // Footer nav
    const base = getBaseUrl();
    el.openAppBtn.addEventListener("click", () => chrome.tabs.create({ url: base }));
    el.viewLeadsBtn.addEventListener("click", () => chrome.tabs.create({ url: `${base}/leads` }));
    el.settingsBtn.addEventListener("click", () => chrome.tabs.create({ url: `${base}/settings` }));
    el.reconnectBtn.addEventListener("click", () => {
      checkSalesIntelConnection();
      checkGoogleMapsTab();
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    updateEnvBadge();
    listenForProgress();
    setupActions();
    // Independent state checks — run in parallel
    checkSalesIntelConnection();
    checkGoogleMapsTab();
  });
})();
