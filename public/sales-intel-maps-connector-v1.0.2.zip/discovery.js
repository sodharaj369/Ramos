/**
 * Disposable DOM Content Worker for Google Maps (v1.0.2).
 * Operates under Background-Owned Orchestration.
 * Re-injection safe: immediately notifies background via SI_CONTENT_READY.
 */
(function () {
  "use strict";

  const adapter = window.SalesIntelMapsAdapter;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function isContextValid() {
    try {
      return Boolean(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  function normalizeName(name) {
    if (!name) return "";
    return String(name).toLowerCase().replace(/['"’]/g, "").replace(/[^a-z0-9]/g, " ").replace(/\s+/g, " ").trim();
  }

  /** Builds candidate identity queue from Google Maps search results */
  function buildCandidateQueue(limit) {
    const queue = [];
    const seen = new Set();
    const cardEls = adapter ? adapter.getVisibleCardElements() : [];

    for (const cardEl of cardEls) {
      if (queue.length >= limit) break;

      let qual = { qualified: false };
      if (adapter && adapter.ResultCardExtractor && adapter.ResultCardExtractor.isBusinessResultCard) {
        qual = adapter.ResultCardExtractor.isBusinessResultCard(cardEl);
      }

      if (!qual || !qual.qualified) continue;

      const cardRecord = adapter ? adapter.extractResultCard(cardEl) : null;
      if (!cardRecord || !cardRecord.company_name) continue;

      const key = adapter ? adapter.localKey(cardRecord) : cardRecord.company_name;
      if (!key || seen.has(key)) continue;

      seen.add(key);
      queue.push({
        company_name: cardRecord.company_name,
        place_id: cardRecord.place_id,
        source_url: cardRecord.source_url,
        category: cardRecord.category,
      });
    }

    return queue;
  }

  /** Performs candidate click & detail panel extraction for active candidate */
  async function handleEnrichCandidate(candidate, index) {
    if (!isContextValid() || !candidate || !candidate.company_name) return;

    const expectedNorm = normalizeName(candidate.company_name);

    // 1. Check if detail panel is ALREADY open for this candidate
    let currentDetail = adapter ? adapter.extractDetailPanel() : null;
    if (currentDetail && currentDetail.company_name) {
      const actualNorm = normalizeName(currentDetail.company_name);
      if (actualNorm.includes(expectedNorm) || expectedNorm.includes(actualNorm)) {
        currentDetail.source = "detail";
        chrome.runtime.sendMessage({
          type: "SI_DETAIL_READY",
          index,
          detailLead: currentDetail,
        });
        return;
      }
    }

    // 2. Locate DOM card element matching candidate identity
    const cardEl = adapter ? adapter.findCurrentCardElement(candidate) : null;

    // 3. Trigger Click
    if (cardEl) {
      try {
        const link = cardEl.querySelector('a.hfpxzc') || cardEl.querySelector('div.qBF1Pd') || cardEl.querySelector('button') || cardEl;
        if (link) {
          if (typeof link.scrollIntoView === "function") {
            link.scrollIntoView({ block: "center" });
          }
          const evt = new MouseEvent("click", { bubbles: true, cancelable: true, view: window });
          link.dispatchEvent(evt);
          if (typeof link.click === "function") {
            link.click();
          }
        }
      } catch (e) {
        /* click attempt */
      }
    }

    chrome.runtime.sendMessage({
      type: "SI_CLICK_ATTEMPTED",
      index,
      name: candidate.company_name,
    });

    // 4. Poll detail panel for up to 20 checks x 400ms = 8000ms max
    let attempts = 0;
    const maxAttempts = 20;

    while (attempts < maxAttempts) {
      await sleep(400);
      attempts++;

      if (!isContextValid()) return; // Context invalidated by navigation

      currentDetail = adapter ? adapter.extractDetailPanel() : null;
      if (currentDetail && currentDetail.company_name) {
        const actualNorm = normalizeName(currentDetail.company_name);
        if (actualNorm.includes(expectedNorm) || expectedNorm.includes(actualNorm)) {
          currentDetail.source = "detail";
          chrome.runtime.sendMessage({
            type: "SI_DETAIL_READY",
            index,
            detailLead: currentDetail,
          });
          return;
        }
      }
    }

    // Timeout reached without matching detail panel
    chrome.runtime.sendMessage({
      type: "SI_CANDIDATE_FAILED",
      index,
      name: candidate.company_name,
      reason: "detail_panel_timeout",
    });
  }

  // --- Initialize Content Script ---
  if (isContextValid()) {
    // Notify background worker that content script is active/ready
    chrome.runtime.sendMessage({ type: "SI_CONTENT_READY" }, () => {
      if (chrome.runtime.lastError) {
        /* ignore background setup */
      }
    });

    // Listen for background requests
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || typeof message.type !== "string") return;

      if (message.type === "BUILD_DISCOVERY_QUEUE") {
        const queue = buildCandidateQueue(message.limit || 2);
        sendResponse({ ok: true, queue });
        return true;
      }

      if (message.type === "ENRICH_CURRENT_CANDIDATE") {
        sendResponse({ ok: true });
        handleEnrichCandidate(message.candidate, message.index);
        return true;
      }

      return undefined;
    });
  }
})();
