/**
 * Discovery Controller for Google Maps (LOOP-ONLY DIAGNOSTIC MODE - 2 BUSINESSES LIMIT).
 * Verifies sequential candidate discovery queue -> click -> detail panel -> identity OK -> complete sequence.
 */
(function () {
  "use strict";

  const adapter = window.SalesIntelMapsAdapter;
  const HARD_MAX = 50;
  const MAX_SCROLLS_WITHOUT_NEW = 4;

  const state = {
    running: false,
    cancelled: false,
    records: [],
    seen: new Set(),
    limit: 2, // TEMPORARY TEST LIMIT: 2 BUSINESSES ONLY
    stats: {
      discovered: 0,
      enrichmentStarted: 0,
      clickAttempted: 0,
      detailPanelReady: 0,
      identityVerified: 0,
      enrichmentCompleted: 0,
    },
    currentBusiness: null,
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function isContextValid() {
    try {
      return Boolean(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  function progress(status, extra) {
    if (!isContextValid()) return;
    const message = Object.assign(
      {
        type: "SI_DISCOVERY_PROGRESS",
        status,
        found: state.records.length,
        processed: state.records.length,
        stats: state.stats,
        currentBusiness: state.currentBusiness,
      },
      extra || {},
    );
    try {
      chrome.runtime.sendMessage(message);
    } catch {
      /* popup closed or context invalid */
    }
  }

  /**
   * Phase 1: Build Candidate Discovery Queue from Search Result Cards.
   */
  async function buildDiscoveryQueue(targetLimit) {
    const queue = [];
    const feed = adapter ? adapter.getFeed() : null;
    let idleScrolls = 0;

    while (
      !state.cancelled &&
      queue.length < targetLimit &&
      idleScrolls < MAX_SCROLLS_WITHOUT_NEW &&
      (!adapter || !adapter.reachedEnd())
    ) {
      const cardEls = adapter ? adapter.getVisibleCardElements() : [];

      for (const cardEl of cardEls) {
        if (state.cancelled || queue.length >= targetLimit) break;

        let qual = { qualified: false };
        if (adapter && adapter.ResultCardExtractor && adapter.ResultCardExtractor.isBusinessResultCard) {
          qual = adapter.ResultCardExtractor.isBusinessResultCard(cardEl);
        }

        if (!qual || !qual.qualified) continue;

        const cardRecord = adapter ? adapter.extractResultCard(cardEl) : null;
        if (!cardRecord || !cardRecord.company_name) continue;

        const key = adapter ? adapter.localKey(cardRecord) : cardRecord.company_name;
        if (!key || state.seen.has(key)) continue;

        state.seen.add(key);
        state.stats.discovered++;

        const candidate = {
          company_name: cardRecord.company_name,
          place_id: cardRecord.place_id,
          source_url: cardRecord.source_url,
          category: cardRecord.category,
        };

        queue.push(candidate);
      }

      if (queue.length >= targetLimit || (adapter && adapter.reachedEnd())) break;

      if (feed) {
        feed.scrollTo({ top: feed.scrollHeight, behavior: "smooth" });
      }
      await sleep(1000);
      idleScrolls++;
    }

    return queue;
  }

  /**
   * Phase 2: Sequential Detail-Panel Enrichment Loop.
   */
  async function enrichQueueSequentially(queue) {
    for (let i = 0; i < queue.length; i++) {
      if (state.cancelled || state.records.length >= state.limit) break;

      const idx = i + 1;
      const candidate = queue[i];
      state.stats.enrichmentStarted++;

      state.currentBusiness = { name: candidate.company_name };
      progress("running", {
        statusText: `[LOOP ${idx}/2] ${candidate.company_name}`,
        currentBusiness: state.currentBusiness,
      });

      // Locate DOM element & click
      const cardEl = adapter ? adapter.findCurrentCardElement(candidate) : null;
      if (cardEl) {
        state.stats.clickAttempted++;
      }

      try {
        if (adapter && adapter.enrichCandidate) {
          const detailLead = await adapter.enrichCandidate(cardEl, candidate, idx);
          if (detailLead && detailLead.company_name && detailLead.source === "detail") {
            state.stats.detailPanelReady++;
            state.stats.identityVerified++;
            state.stats.enrichmentCompleted++;

            state.records.push(detailLead);
          }
        }
      } catch (err) {
        /* error handled in adapter */
      }

      progress("running", { currentBusiness: state.currentBusiness });
      await sleep(600);
    }
  }

  async function runBulkDiscovery(limit) {
    if (state.running) return { ok: false, error: "Discovery is already running." };
    if (!adapter || !adapter.isSearchResultsPage()) {
      return {
        ok: false,
        code: "NO_SEARCH_RESULTS",
        error: "No qualified Google Maps search results found. Search for a business category or location on Google Maps first.",
      };
    }

    state.running = true;
    state.cancelled = false;
    state.records = [];
    state.seen = new Set();
    state.limit = Math.min(Math.max(Number(limit) || 2, 1), HARD_MAX);
    state.stats = {
      discovered: 0,
      enrichmentStarted: 0,
      clickAttempted: 0,
      detailPanelReady: 0,
      identityVerified: 0,
      enrichmentCompleted: 0,
    };
    state.currentBusiness = null;

    // Phase 1: Build Discovery Queue
    const queue = await buildDiscoveryQueue(state.limit);

    // Phase 2: Sequential Detail Panel Enrichment Loop
    await enrichQueueSequentially(queue);

    state.running = false;
    console.log("[SI][LOOP][SUMMARY]", JSON.stringify(state.stats));

    if (state.cancelled) {
      const count = state.records.length;
      state.records = [];
      state.seen = new Set();
      progress("cancelled", { found: 0, processed: 0, discarded: count, stats: state.stats });
      return { ok: true, cancelled: true, records: [], stats: state.stats };
    }

    const records = state.records.slice(0, state.limit);
    progress("completed", { found: records.length, processed: records.length, stats: state.stats });
    return { ok: true, cancelled: false, records, stats: state.stats };
  }

  if (isContextValid()) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || typeof message.type !== "string") return;
      if (sender.id !== chrome.runtime.id) return;

      if (message.type === "SI_PAGE_STATE") {
        const isMaps = adapter ? adapter.isMapsPage() : false;
        const qualifiedCards = (isMaps && adapter) ? adapter.getQualifiedCardElements() : [];
        const detected = qualifiedCards.length;
        const isResults = detected > 0;
        const query = adapter ? adapter.currentQuery() : null;

        sendResponse({
          ok: true,
          isMaps,
          isResults,
          query,
          detected,
          running: state.running,
          stats: state.stats,
          currentBusiness: state.currentBusiness || null,
          readyCount: state.records.length,
          records: state.records,
          url: typeof location !== "undefined" ? location.href : "",
        });
        return true;
      }

      if (message.type === "SI_START_DISCOVERY") {
        runBulkDiscovery(message.limit || 2).then(sendResponse, (err) =>
          sendResponse({
            ok: false,
            code: "EXTRACTION_FAILED",
            error: err && err.message ? err.message : "Discovery failed.",
          }),
        );
        return true;
      }

      if (message.type === "SI_STOP_DISCOVERY") {
        state.cancelled = true;
        sendResponse({ ok: true });
        return true;
      }

      return undefined;
    });
  }
})();
